package me.mcluke300.playerlogger.commands;

import me.mcluke300.playerlogger.*;
import org.bukkit.command.*;
import org.bukkit.*;
import me.mcluke300.playerlogger.config.*;
import me.mcluke300.playerlogger.mysql.*;

public class playerloggerCommand implements CommandExecutor
{
    private playerlogger plugin;
    
    public playerloggerCommand(final playerlogger plugin) {
        this.plugin = plugin;
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String commandLabel, final String[] args) {
        if (commandLabel.equalsIgnoreCase("playerlogger")) {
            if (args.length == 0) {
                sender.sendMessage(ChatColor.RED + "Usage: /playerlogger reload");
                return false;
            }
            if (args.length == 1) {
                if (args[0].equalsIgnoreCase("reload") && sender.hasPermission("PlayerLogger.reload")) {
                    this.plugin.reloadConfig();
                    getConfig.getValues();
                    mysql.createDatabase();
                    sender.sendMessage(ChatColor.GREEN + "PlayerLogger Config Reloaded");
                }
            }
            else if (args.length < 2) {
                return false;
            }
        }
        return false;
    }
}
