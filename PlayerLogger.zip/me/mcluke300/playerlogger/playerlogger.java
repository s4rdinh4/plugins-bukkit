package me.mcluke300.playerlogger;

import org.bukkit.plugin.java.*;
import me.mcluke300.playerlogger.commands.*;
import me.mcluke300.playerlogger.config.*;
import me.mcluke300.playerlogger.mysql.*;
import org.bukkit.*;
import me.mcluke300.playerlogger.listeners.*;
import org.bukkit.event.*;
import org.bukkit.plugin.*;
import org.bukkit.command.*;
import java.io.*;

public class playerlogger extends JavaPlugin
{
    File subdir;
    File subdir2;
    public static playerlogger plugin;
    private playerloggerCommand executor;
    
    public playerlogger() {
        this.subdir = new File("plugins/PlayerLogger/Users");
        this.subdir2 = new File("plugins/PlayerLogger/Staff");
    }
    
    public void onEnable() {
        playerlogger.plugin = this;
        if (!this.subdir.exists()) {
            this.subdir.mkdir();
        }
        if (playerlogger.plugin.getConfig().getBoolean("Log.SeparateFolderforStaff") && !this.subdir2.exists()) {
            this.subdir2.mkdir();
        }
        config.LoadConfiguration();
        getConfig.getValues();
        mysql.createDatabase();
        Bukkit.getServer().getPluginManager().registerEvents((Listener)new PListener(this), (Plugin)this);
        this.executor = new playerloggerCommand(this);
        this.getCommand("playerlogger").setExecutor((CommandExecutor)this.executor);
        try {
            final MetricsLite metrics = new MetricsLite((Plugin)this);
            metrics.start();
        }
        catch (IOException ex) {}
    }
    
    public void onDisable() {
    }
}
